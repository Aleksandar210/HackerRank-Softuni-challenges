
public  class Card {
	private String type;
	private double discountRate;
	private double purchaseValue;
	private double discount;
	private double total;
	
	
	
	public Card(String type, double purchaseValue, int turnover) {
		
	this.type =type;
	this.purchaseValue =purchaseValue;
	calculateDiscountRate(turnover);
	this.discount = this.purchaseValue*this.discountRate;
	
	}
	
	private void calculateDiscountRate(int turnover) {
		switch(this.type.toLowerCase()) {
		
		case "gold":
			this.discountRate=2;		//the initial  2%
			
			turnover/=100;
			this.discountRate+=turnover;
			
			if(discountRate>10)
				discountRate=10;
			break;
			
		case "silver":
			this.discountRate=2;
			if(turnover>300) {
				this.discountRate=3.5;
			}
			break;
			
		case "bronze":
			if(turnover<100) {
			this.discountRate=0;
			}else if(turnover>=100 && turnover<=300) {
				this.discountRate=2.5;
			}else {
				this.discountRate = 3.5;
			}
			break;
		}
		
		
	}

	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	public double getPurchaseValue() {
		return purchaseValue;
	}

	public void setPurchaseValue(double purchaseValue) {
		this.purchaseValue = purchaseValue;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public String displayTotal() {
		String returnThis  =String.format("%.2f", this.total);
		return returnThis;
	}

}
