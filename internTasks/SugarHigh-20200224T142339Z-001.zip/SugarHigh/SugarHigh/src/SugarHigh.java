import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SugarHigh {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		String enterCandies = scan.nextLine();
		String[] enterSplited = enterCandies.split(" ");
		ArrayList<Integer> candies = new ArrayList<Integer>(enterSplited.length);
		fillArrayList(candies,enterSplited);
		int treshold = Integer.parseInt(scan.nextLine());
		scan.close();
		ArrayList<CalorieIndex> temp = sugarHigh(candies,treshold);
		CalorieIndex currentBestIndex =getBestOption(temp);
		currentBestIndex.show();
		
		
		
	}
	static void fillArrayList(ArrayList<Integer>candies,String[] numbers) {
		for(int i =0;i<numbers.length;i++) {
			candies.add(Integer.parseInt(numbers[i]));
		}
	}
	
	static ArrayList<CalorieIndex> sugarHigh(ArrayList<Integer> candies , int treshold) {
		ArrayList<CalorieIndex> calorieIndexes = new ArrayList<CalorieIndex>();
		//eliminate elements who surpass the treshold
		for(int i =0;i<candies.size();i++) {
			if(candies.get(i)>=treshold) {
				candies.remove(i);
			}
		}
		
		//calculating the calories for the rest
		for(int i =0;i<candies.size();i++) {
			if(candies.size()==1) {
				break;
			}
			int sum=candies.get(i);
			ArrayList<Integer> indxs = new ArrayList<Integer>();
			indxs.add(i);
			for(int j = i+1;j<candies.size()-1;j++) {
				if(candies.get(j)+sum<treshold) {
					sum += candies.get(j);
					indxs.add(j);
				}
			}
			calorieIndexes.add(new CalorieIndex(sum,indxs));
			candies.remove(i);
			
		}
		
		
		return calorieIndexes;
	}
	
	
	static CalorieIndex getBestOption(ArrayList<CalorieIndex> indxs) {
		CalorieIndex bestOption = new CalorieIndex();
		bestOption = indxs.get(0);
		for(int i =1;i<indxs.size();i++) {
			if(indxs.get(i).getCount()>bestOption.getCount() && indxs.get(i).getIndex()<bestOption.getIndex()) {
				bestOption = indxs.get(i);
			}
		}
		
		return bestOption;
		
		
	}
	
	}
	
	


